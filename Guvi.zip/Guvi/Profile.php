<?php
$conn=mysqli_connect("localhost","root","","guvi");
if(isset($_POST['sub'])) 
{
	$mail=$_POST['mail'];
	$user=$_POST['pass'];
$confirm = mysqli_query($conn,"SELECT * FROM signup WHERE `mail`='$mail' AND  `upass`='$user' ");
$count_confirm = mysqli_num_rows($confirm);

if($count_confirm==1)
{
	echo "<script> alert('Login Successfully'); </script>";
	//echo "<meta http-equiv='refresh' content='0; URL=Profile.php' />";	
	
}
else
{
	echo "<script> alert('Enter Valid User Name And Password'); </script>";
	echo "<meta http-equiv='refresh' content='0; URL=login.php' />";	
		

}

 
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>USER PROFILE</title>
	<link rel="stylesheet" type="text/css" href="dist/css/bootstrap.css">
	<link rel="stylesheet" href="dist/css/style.css">
	<link rel="stylesheet" type="text/css" href="dist/css/font-awesome.min.css">
	<link rel="icon" type="image/png" href="images/icon.ico"/>
</head>
<body>
  <h1 class="text-danger" style="text-align: center;">YOUR PROFILE</h1>
  
  <hr>

<div class="row" style="margin-left: 250px;">
<div class="col-sm-8">
	<table class="table table-bordered">
		<thead class="thead-dark">
			<tr>
				<th>Slno</th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Birthday</th>
				<th>Gender</th>
				<th>Mail Id</th>
				<th>Phone Number</th>
				<th>Password</th>
				<th>Confirm Password</th>
				<th>Course</th>
			</tr>
		</thead>
		<tbody>
			<?php
				$sno=1;
				$view_signup = mysqli_query($conn,"SELECT * FROM signup WHERE `mail`='".$mail."' ");
				$row_signup = mysqli_fetch_array($view_signup);
				?>
			<tr>				
				<td><?php echo $sno; ?></td>
				<td><?php echo $row_signup['fname']; ?></td>
				<td><?php echo $row_signup['lname']; ?></td>
				<td><?php echo $row_signup['birthday']; ?></td>
				<td><?php echo $row_signup['gender']; ?></td>
				<td><?php echo $row_signup['mail']; ?></td>
				<td><?php echo $row_signup['phone']; ?></td>
				<td><?php echo $row_signup['upass']; ?></td>
				<td><?php echo $row_signup['conpassword']; ?></td>
				<td><?php echo $row_signup['subject']; ?></td>
			</tr>
		</tbody>
	</table>
</div> 
</div>
<button class="btn btn-danger" style="margin-left: 620px;"><i class="fa fa-power-off"></i><a class="text-white" style="text-decoration: none;" href="login.php">LOGOUT</a></button>
</center>
<div class="footer">
	<div class="text">
	<br>Copyright ©2019 All rights reserved | This Website was Designed by A.Joseph Arul Selvam III MCA | joekuttydb@gmail.com | EGS Pillay Engineering College.
	</div>
</div>
</body>
</html>